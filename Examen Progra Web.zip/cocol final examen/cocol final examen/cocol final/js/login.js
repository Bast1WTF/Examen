var correo = document.getElementById("correo");
var contraseña = document.getElementById("contraseña");
var error = document.getElementById("error");
var regexEmail = /^\w+([.-]?\w+)@\w+([.-]?\w+)(.\w{2,4})+$/

function logearse(){
    console.log("Ingresando...");
    var msjerror = [];

    if(correo.value === null || correo.value === ""){
        msjerror.push("ingrese su correo");
    }else if(!regexEmail.test(correo.value)){
        msjerror.push("ingrese un correo valido");
    }

    if(contraseña.value === null || contraseña.value === ""){
        msjerror.push("ingrese una contraseña");
    }else if(contraseña.value.length < 6){
        msjerror.push("contraseña muy corta");
    }

    error.innerHTML = msjerror.join(",");

    return false;
}