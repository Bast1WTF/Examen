var nombre = document.getElementById("nombre");
var correo = document.getElementById("correo");
var telefono = document.getElementById("telefono");
var asunto = document.getElementById("asunto");
var mensaje = document.getElementById("mensaje");
var error = document.getElementById("error");
var regexEmail = /^\w+([.-]?\w+)@\w+([.-]?\w+)(.\w{2,4})+$/

function registrarse(){
    console.log("Enviando...");
    var msjerror = [];

    if(nombre.value === null || nombre.value === ""){
        msjerror.push("ingrese su nombre");
    }

    if(correo.value === null || correo.value === ""){
        msjerror.push("ingrese su correo");
    }else if(!regexEmail.test(correo.value)){
        msjerror.push("ingrese un correo valido");
    }

    if(telefono.value === null || telefono.value === ""){
        msjerror.push("ingrese su telefono");
    }else if(telefono.value.length < 9){
        msjerror.push("ingrese un numero valido");
    }

    if(nomasuntobre.value === null || asunto.value === ""){
        msjerror.push("ingrese el asunto");
    }

    if(mensaje.value === null || mensaje.value === ""){
        msjerror.push("ingrese un mensaje");
    }

    error.innerHTML = msjerror.join(",");

    return false;
}